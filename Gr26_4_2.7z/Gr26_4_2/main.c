/*
 * ByggernGr26.c
 *
 * Created: 12.09.2024 09:16:29
 * Author : torstepu
 */ 
#include <stdio.h>
#include <stdint.h>
#include <avr/io.h>
#include <stdlib.h>
#include "UART.h"
#include "SRAM.h"
#include "XMEM.h"
//#include "NANDtest.h"
#include "ADC.h"
#include "OLED.h"
#include <string.h>



int main(void)
{
	xmem_init();
	
    USART_Init(MYUBRR);

    uart_setup_stdio();
	
	printf("-------------------PROGRAM STARTV3-------------------\n");

	adc_init();
	
	OLED_init();
	
	
	OLED_home();
	_delay_ms(1000);
	
    while (1){
		for(uint8_t i = 1; i < 5; i++){
			OLED_invert_page(i);
			_delay_ms(1000);
		}
	OLED_reset();
	OLED_home();
 		
		 //joyStickClick();
		
		

    }
}

