/*
 * NANDtest.h
 *
 * Created: 12.09.2024 17:08:28
 *  Author: torstepu
 */ 

#include <avr/io.h>
#include <stdio.h>

#ifndef NANDTEST_H
#define NANDTEST_H


void test_nand(int x);


#endif /* NANDTEST_H */