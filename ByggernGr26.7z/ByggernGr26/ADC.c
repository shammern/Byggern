/*
 * ADC.c
 *
 * Created: 19.09.2024 12:53:33
 *  Author: torstepu
 */ 
#include "ADC.h"
void adc_init(void){
	// Sett PD5 (OC1A) som utgang
	DDRD |= (1 << PD5);

	// Sett Timer/Counter1 til Fast PWM-modus, 8-bit
	// WGM12:0 = 011 (Fast PWM, 8-bit)
	// COM1A1:0 = 10 (Clear OC1A on compare match, set OC1A at BOTTOM)
	TCCR1A |= (1 << WGM10) | (1 << WGM11) | (1 << COM1A0) ;
	TCCR1B |= (1 << WGM12) | (1 << WGM13) | (1 << CS10); // Sett prescaler til 8
	
	

	// Sett initial PWM-verdi (duty cycle)
	//OCR1A = 128; // 50% duty cycle
	
	
	
}

void adc_read(uint16_t channel, JoyStick *Stick){
	xmem_write(1, channel);
	_delay_us(15);
	Stick->y_value = xmem_read(channel);
	Stick->x_value = xmem_read(channel);
}


void test_adc(void){
	JoyStick Stick;
	adc_read(0x400, &Stick);
	joyStickPos(&Stick);
	printf("------------------------------------\n");
	printf("The X-Value is : %d\n", Stick.x_value);
	printf("The Y-Value is : %d\n", Stick.y_value);
	printf("The X-per is : %d\n", Stick.x_percent);
	printf("The Y-per is : %d\n", Stick.y_percent);
	joyStickDir(&Stick);		
}

void joyStickPos(JoyStick *Stick){
	//Updates X values
	if (Stick->x_value>170){
		Stick->x_percent = ((int16_t)(Stick->x_value - 168) * 100) / 87;
	}
	else if (Stick->x_value<165){
		Stick->x_percent = ((int16_t)(Stick->x_value - 168) * 100) / 168;
	}
	
	else{
		Stick->x_percent = 0;
	}
	//updates Y values
	if (Stick->y_value>170){
		Stick->y_percent = ((int16_t)(Stick->y_value - 168) * 100) / 87;
	}
	else if (Stick->y_value<165){
		Stick->y_percent = ((int16_t)(Stick->y_value - 168) * 100) / 168;
	}		
	
	else{
		Stick->y_percent = 0;
	}
}

int8_t uint8_to_percentage(uint8_t input) {
	// Scale the input from 0-255 to -100 to 100
	return ((int16_t)(input - 168) * 100) / 87;
}

direction joyStickDir(JoyStick *Stick){
	uint8_t x = abs(Stick->x_percent);
	uint8_t y = abs(Stick->y_percent);
	if (x>y){
		if (Stick->x_percent>0){
			printf("RIGHT");
			return RIGHT;
		}
		printf("LEFT");
		return LEFT;
	}
	
	else if (x<y){
		if (Stick->y_percent>0){
			printf("UP");
			return UP;
		}
		printf("DOWN");
		return DOWN;
	}
	
	else{
		printf("NEUTRAL");
		return NEUTRAL;
	}
}