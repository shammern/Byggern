/*
 * ADC.h
 *
 * Created: 19.09.2024 12:53:54
 *  Author: torstepu
 */ 

#include <stdio.h>
#include <avr/io.h>
#include <stdlib.h>
#include <stdint.h>
#include <util/delay.h>
#include "XMEM.h"


#ifndef ADC_H_
#define ADC_H_

typedef struct{
	uint8_t x_value;
	uint8_t y_value;
	int8_t x_percent;
	int8_t y_percent;
} JoyStick;

typedef enum{
	UP,
	DOWN,
	RIGHT,
	LEFT,
	NEUTRAL
} direction;



void adc_init(void);
void adc_read(uint16_t channel, JoyStick *Stick); //Volatile
void pos_calibrate();
//pos_t pos_read(void);
void test_adc(void);
void joyStickPos(JoyStick *Stick);
int8_t uint8_to_percentage(uint8_t input);
direction joyStickDir(JoyStick *Stick);



#endif /* ADC_H_ */