/*
 * OLED.c
 *
 * Created: 26.09.2024 12:54:14
 *  Author: torstepu
 */ 
#include "OLED.h"

void OLED_write(uint8_t adress){
	volatile char *ext_mem = (char*) BASE_ADDRESS;
	ext_mem[0] = adress;
}


void OLED_init(){
	OLED_write(0xae); // display off
	OLED_write(0xa1); //segment remap
	OLED_write(0xda); //common pads hardware: alternative
	OLED_write(0x12);
	OLED_write(0xc8); //common output scan direction:com63~com0
	OLED_write(0xa8); //multiplex ration mode:63
	OLED_write(0x3f);
	OLED_write(0xd5); //display divide ratio/osc. freq. mode
	OLED_write(0x80);
	OLED_write(0x81); //contrast control
	OLED_write(0x50);
	OLED_write(0xd9); //set pre-charge period
	OLED_write(0x21);
	OLED_write(0x20); //Set Memory Addressing Mode
	OLED_write(0x02);
	OLED_write(0xdb); //VCOM deselect level mode
	OLED_write(0x30);
	OLED_write(0xad); //master configuration
	OLED_write(0x00);
	OLED_write(0xa4); //out follows RAM content
	OLED_write(0xa6); //set normal display
	OLED_write(0xaf); // display on
	OLED_write(0xa5); //Turns on all pixels
}