/*
 * SRAM.h
 *
 * Created: 12.09.2024 09:31:25
 *  Author: torstepu
 */ 
#include <stdio.h>
#include <avr/io.h>

#ifndef SRAM_H
#define SRAM_H


void SRAM_test(void);


#endif /* SRAM_H */