/*
 * OLED.h
 *
 * Created: 26.09.2024 12:54:02
 *  Author: torstepu
 */ 

#include <stdio.h>
#include <avr/io.h>
#include <stdlib.h>
#include <stdint.h>
#include "XMEM.h"

#ifndef OLED_H_
#define OLED_H_

void OLED_init();
void OLED_reset();
void OLED_home();
//void OLED_goto_line(line);
//void OLED_clear_line(line);
//void OLED_pos(row, column);
void OLED_write_data(char charr); //volatile
void OLED_print(char* charr);
void OLED_set_brightness(uint8_t level);
void OLED_write(uint8_t adress);




#endif /* OLED_H_ */